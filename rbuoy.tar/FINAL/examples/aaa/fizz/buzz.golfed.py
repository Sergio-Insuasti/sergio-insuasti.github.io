i=0
while(i:=i+1):print([i,'fizz...','buzz?','fizz buzz!'][(i%3<1)+2*(i%5<1)])
