////////////////////////////////////////////////////////////////////////
// COMP1521 24T2 --- Assignment 2: `rbuoy', a simple file synchroniser
// <https://cgi.cse.unsw.edu.au/~cs1521/24T2/assignments/ass2/index.html>
//
// Written by SERGIO INSUASTI (z5338374) on 19-07-2024 to 02-08-2024.
// 
// ASSIGNMENT 2: RBUOY FILE SYNCHRONISER:
// This assignment takes custom binary files formats (TABI, TBBI, TCBI).
// RBUOY then converts, updates and maintains data distributed across users
// (sender and receiver), through the implementation of a variety of functions.
// The aim of rbuoy is to maintain data integrity, and ensure portability across
// all systems.
//
// 2024-07-12   v1.0    Team COMP1521 <cs1521 at cse.unsw.edu.au>


#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <limits.h>
#include "rbuoy.h"

///////////////////////////////////CONSTANTS////////////////////////////////////

#define NUM_UPDATES_SIZE 3

#define MAX_PATH_LENGTH 4096

/////////////////////////////FUNCTION PROTOTYPES////////////////////////////////

/////////////////////////////////STAGE 1////////////////////////////////////////

void make_little_endian (FILE *file, uint64_t value, uint64_t n_bytes);

void write_file_to_tabi (FILE *f_out, char *out_pathname, char *in_pathname);

/////////////////////////////////STAGE 2////////////////////////////////////////

struct tabi_record read_tabi_file (FILE *file_in, char *in_pathname);

uint64_t read_little_endian (
    FILE *file_in, 
    char *in_pathname, 
    size_t n_bytes, 
    char *field_name, 
    char *txbi_string);

void free_tabi_record(struct tabi_record *tabi_record);

void write_magic_txbi_header(
    FILE *file_out, 
    char*string, 
    char *out_pathname, 
    uint8_t num_records);

uint8_t read_magic_txbi_header(FILE *file_in, char *string, char *in_pathname);

void check_matches (struct tabi_record *tabi_record, uint8_t match_number[]);

/////////////////////////////////STAGE 3////////////////////////////////////////

struct tbbi_record read_tbbi_file(FILE *file_in, char *in_pathname);

void establish_record (
    FILE *file_in, 
    FILE *file_out, 
    char *in_pathname, 
    char *out_pathname);

void tcbi_pathname(FILE *file_out, struct tbbi_record *tbbi_record);

void print_permissions (FILE *file_out, mode_t mode, char *out_pathname);

int count_updates (struct tbbi_record *tbbi_record);

void write_updates(
    struct tbbi_record *tbbi_record,
    FILE *file_out, 
    char *out_pathname);

void free_tbbi_record(struct tbbi_record *tbbi_record);


/////////////////////////////////STAGE 4////////////////////////////////////////

struct tcbi_record read_tcbi_file (FILE *file_in, char *in_pathname);

void establish_records_s4 (FILE *file_in, char *in_pathname);

void directory_record(struct tcbi_record *tcbi_record);

void check_permissions (
    struct tcbi_record *tcbi_record, 
    FILE *file_in,
    char *in_pathname);

void open_and_update_tcbi (
    struct tcbi_record *tcbi_record, 
    FILE *file_in, 
    char *in_pathname);

void update_bytes_loop (
    struct tcbi_record *tcbi_record, 
    FILE *file_in, 
    char *in_pathname,
    size_t num_sender_blocks,
    int file_descriptor);


int block_index_check (
    FILE *file_in,
    char *in_pathname,
    size_t num_sender_blocks,
    int *seen
    );

void move_and_update_bytes (
    int file_descriptor, 
    int block_index,
    uint16_t update_length,
    FILE *file_in,
    char *in_pathname
    );

void free_tcbi_record(struct tcbi_record *tcbi_record);



///////////////////////////SUBSET 5 HELPER FUNCTIONS////////////////////////////

int directory_to_tabi (FILE *file_out, char *directory_name);

void write_directory_to_tabi(FILE *file_out, char *directory_name);

int check_invalid_paths (char *in_pathname);

////////////////////////////////////////////////////////////////////////////////
/////////////////////////////STRUCTS & ENUMS////////////////////////////////////

struct tabi_record {
    uint16_t pathname_len;
    char *pathname;
    uint32_t num_blocks;
    uint64_t *hashes;
};

struct tbbi_record {
    uint16_t pathname_len;
    char *pathname;
    uint32_t num_blocks;
    uint8_t *matches;
};

struct tcbi_record {
    uint16_t pathname_len;
    char *pathname;
    char *mode;
    mode_t permission;
    uint32_t size;
    uint32_t num_updates; 
};

////////////////////////////////////////////////////////////////////////////////

/// @brief Create a TABI file from an array of pathnames.
/// @param out_pathname A path to where the new TABI file should be created.
/// @param in_pathnames An array of strings containing, in order, the files
//                      that should be placed in the new TABI file.
/// @param num_in_pathnames The length of the `in_pathnames` array. In
///                         subset 5, when this is zero, you should include
///                         everything in the current directory.

void stage_1(
    char *out_pathname, 
    char *in_pathnames[], 
    size_t num_in_pathnames) {

    FILE *f = fopen(out_pathname, "w");
    if (f == NULL) {
        perror(out_pathname);
        exit(1);
    }
    
    write_magic_txbi_header(f, TYPE_A_MAGIC, out_pathname, num_in_pathnames);

    if (num_in_pathnames == 0) {
        char *current_directory = getcwd(NULL, 0);
        if (current_directory == NULL) {
            perror("getcwd");
            exit(1);
        }
        int num_records = directory_to_tabi(f, ".");
        free(current_directory);

        fseek(f, MAGIC_SIZE, SEEK_SET);
        make_little_endian(f, num_records, NUM_RECORDS_SIZE);
    }
    else {
        for (size_t i = 0; i < num_in_pathnames; i++) {
            write_file_to_tabi (f, out_pathname, in_pathnames[i]);
        }
    }
    fclose (f);
}

//Function purpose: To take in a value and rearrange its data, storing the LSB 
//                  at the smallest address.
//
//Output:           void
//
//Input:            FILE *file, uint64_t value, uint64_t n_bytes
//
//Name:             make_little_endian
//
void make_little_endian (FILE *file, uint64_t value, uint64_t n_bytes) {
    for (int i = 0; i < n_bytes; i++) {
        if (fputc(value >> (i * 8), file) == EOF) {
            perror("make_little_endian");
            exit(1);
        }
    }
}

//Function purpose: Take in file's data and write L-Endian values
//                  into a TABI file.
//
//Output:           void
//
//Input:            FILE *f_out, char *out_pathname, char *in_pathname
//
//Name:             write_file_to_tabi
//
void write_file_to_tabi (FILE *f_out, char *out_pathname, char *in_pathname) {

    struct stat s;
    if (stat(in_pathname, &s) != 0) {
        perror(in_pathname);
        exit(1);
    }

    if (S_ISDIR(s.st_mode)) {
        fprintf(stderr, "ERROR: %s is a directory.\n", in_pathname);
        return;
    }


    FILE *f_in = fopen (in_pathname, "r");
    if (f_in == NULL) {
        fprintf(stderr,"ERROR: No such file or directory.\n");
        exit(1);
    }

    unsigned int path_name_length = strlen(in_pathname);
    make_little_endian(f_out, path_name_length, PATHNAME_LEN_SIZE);
    fwrite(in_pathname, sizeof(char), path_name_length, f_out);


    size_t file_size = s.st_size;

    int num_blocks = number_of_blocks_in_file(file_size);

    make_little_endian(f_out, num_blocks, NUM_BLOCKS_SIZE);
    
    char block[BLOCK_SIZE] = {0};
    for (int i = 0; i < num_blocks; i++) {
        size_t bytes_read = fread(block, 1, BLOCK_SIZE, f_in);
        if (bytes_read < BLOCK_SIZE) {
            if (ferror(f_in)) {
                perror(in_pathname);
                exit(1);
            }
        }
        uint64_t hash = hash_block(block, bytes_read);
        make_little_endian(f_out, hash, HASH_SIZE);
    }

    fclose(f_in);
}

/// @brief Create a TBBI file from a TABI file.
/// @param out_pathname A path to where the new TBBI file should be created.
/// @param in_pathname A path to where the existing TABI file is located.
void stage_2(char *out_pathname, char *in_pathname) {
    FILE *f_in = fopen(in_pathname, "r");
    if (f_in == NULL) {
        perror(in_pathname);
        exit(1);
    }
    FILE *f_out = fopen(out_pathname, "w");
    if (f_out == NULL) {
        perror(out_pathname);
        exit(1);
    }    

    uint8_t num_records = read_magic_txbi_header(f_in,TYPE_A_MAGIC,in_pathname);
    write_magic_txbi_header(f_out, TYPE_B_MAGIC, out_pathname, num_records);

    for (int i = 0; i < num_records; i++) {
        struct tabi_record record = read_tabi_file(f_in, in_pathname);
        
        make_little_endian(f_out, record.pathname_len, PATHNAME_LEN_SIZE);
        size_t path_write = fwrite(record.pathname, sizeof(char), 
                                    record.pathname_len, f_out);
    
        if (path_write < record.pathname_len) {
            perror(out_pathname);
            exit(1);
        }
        make_little_endian(f_out, record.num_blocks, NUM_BLOCKS_SIZE);

        uint8_t match_byte = num_tbbi_match_bytes(record.num_blocks);
        uint8_t *match_number = calloc(match_byte, sizeof(uint8_t));
        
        check_matches(&record, match_number);

        size_t match_write = fwrite(match_number, 1, match_byte, f_out);
        if (match_write < match_byte) {
            perror(out_pathname);
            exit(1);
        }
        free_tabi_record(&record);
    }

    if (fgetc(f_in) != EOF) {
        fprintf(stderr, "Invalid TABI file: leftover data.\n");
        exit(1);
    } else if (ferror(f_in)) {
        perror(in_pathname);
        exit(1);
    }
    fclose (f_in);
    fclose (f_out);
}

//Function purpose: Read in a TABI file and create a struct to easily recall
//                  data in later functions.
//
//Output:           struct tabi_record
//
//Input:            FILE *file_in, char *in_pathname
//
//Name:             read_tabi_file
// 
struct tabi_record read_tabi_file (FILE *file_in, char *in_pathname) {

    struct tabi_record record;

    record.pathname_len = read_little_endian (file_in, in_pathname,
                                                PATHNAME_LEN_SIZE, 
                                                "filename len", 
                                                TYPE_A_MAGIC);

    record.pathname = malloc(sizeof(char) * (record.pathname_len + 1));
    if (record.pathname == NULL) {
        perror("read_tabi_file");
        exit(1);
    }

    int path_read = fread(record.pathname, 1, record.pathname_len, file_in);
    if (path_read < record.pathname_len) {
        if (feof(file_in)) {
            fprintf(stderr, 
            "Invalid TABI file: encountered early end-of-file\
             when trying to read the field\
             `filename' (%d bytes)\n", record.pathname_len);
            exit(1);
        }
        else {
            perror(in_pathname);
            exit(1);
        }
    }
    record.pathname[record.pathname_len] = '\0';

    record.num_blocks = read_little_endian (file_in, in_pathname, 
                                            NUM_BLOCKS_SIZE, "num blocks", 
                                            TYPE_A_MAGIC);

    record.hashes = malloc(sizeof(uint64_t) * record.num_blocks);
    if (record.hashes == NULL) {
        perror("read_tabi_file");
        exit(1);
    }
    for (uint32_t i = 0; i < record.num_blocks; i++){
        record.hashes[i] = read_little_endian(file_in, in_pathname, 
                                              HASH_SIZE, "hash", TYPE_A_MAGIC);
    }

    return record;
}

//Function purpose: To take in a value and rearrange its data, storing the MSB 
//                  at the smallest address. 
//                  Returns num_records parameter if successful.
// 
//Output:           uint64_t
// 
//Input:            FILE *file_in, char *in_pathname, size_5 n_bytes, 
//                  char *field_name, char *txbi_string
// 
//Name:             read_little_endian
// 
uint64_t read_little_endian (FILE *file_in, char *in_pathname, 
                            size_t n_bytes, char *field_name, char *txbi_string) 
                            {
    uint64_t value = 0;
    for (size_t i = 0; i < n_bytes; i++) {
        int byte = fgetc(file_in);
        if (byte == EOF) {
            if (feof(file_in)) {
                fprintf(stderr, "Invalid %s file: encountered early \
                end-of-file when trying to read the field \
                '%s' (%zu bytes)\n", txbi_string, field_name, n_bytes);
                exit(1);
            }
            else {
                perror("read_little_endian");
                exit(1);
            }
        }   
        value |= ((uint64_t)byte << (8 * i));
    }
    return value;
}

//Function purpose: Reads the header of a TXBI file and checks for  errors 
//                  before creating new TXBI file (e.g. TABI -> TBBI).
//                  Returns value for num_records to indicate success.
// 
//Output:           uint8_t
// 
//Input:            FILE *file_in, char *string, char *in_pathname
// 
//Name:             read_magic_txbi_header
// 
uint8_t read_magic_txbi_header(FILE *file_in, char *string, char *in_pathname) {
    for (int i = 0; i < MAGIC_SIZE; i++) {
        int c = fgetc(file_in);
        if (c == EOF) {
            if (feof(file_in)) {
                fprintf(stderr, 
                "Invalid %s file: encountered early end-of-file\
                 when trying to read the field `magic'\
                (%d bytes)\n", string, MAGIC_SIZE);
                exit(1);
            } else {
                perror(in_pathname);
                exit(1);
            }
        }
        if (c != string[i]) {
            fprintf(stderr,"Invalid %s file: incorrect magic number\n", string);
            exit(1);
        }
    }

    int num_records = fgetc(file_in);
    if (num_records == EOF) {
        if(feof(file_in)) {
            fprintf(stderr, 
            "Invalid %s file: encountered early end-of-file when \
            trying to read the field\
            'num records' (%d bytes).\n", string, NUM_RECORDS_SIZE);
            exit(1);
        }
        else {
            perror(in_pathname);
            exit(1);
        }
    }
    return num_records;
}

//Function purpose: Following success of reading header, function writes header
//                  in format of new file.
// 
//Output:           void
// 
//Input:            FILE *file_out, char *string, char *out_pathname, 
//                  uint8t num_records
// 
//Name:             write_magic_txbi_header
// 
void write_magic_txbi_header(
    FILE *file_out, 
    char *string, 
    char *out_pathname, 
    uint8_t num_records) {
        
    size_t magic_write = fwrite(string, 1, MAGIC_SIZE, file_out);

    if (magic_write < MAGIC_SIZE) {
        perror(out_pathname);
        exit(1);
    }
    make_little_endian(file_out, num_records, NUM_RECORDS_SIZE);
}

//Function purpose: Checks if any errors occur when determining 
//                  which block hashes match within a TABI file. 
// 
//Output:           void
// 
//Input:            struct tabi_record *tabi_record, uint8_t match_number[]
// 
//Name:             check_matches
// 
void check_matches (struct tabi_record *tabi_record, uint8_t match_number[]) {
    FILE *loop_file = fopen(tabi_record->pathname, "r");
    
    if (loop_file != NULL) {
        check_invalid_paths(tabi_record->pathname);

        for (uint32_t j = 0; j < tabi_record->num_blocks; j++) {

            char block[BLOCK_SIZE];

            size_t bytes_read = fread(block, 1, BLOCK_SIZE, loop_file);

            if (bytes_read < BLOCK_SIZE && ferror(loop_file)) {
                perror(tabi_record->pathname);
                exit(1);
            }

            if (bytes_read > 0) {
                uint64_t hash = hash_block(block, bytes_read);
                if (hash == tabi_record->hashes[j]) {
                    uint32_t match_index = j / 8;
                    int bit_matched = (7 - j % 8);

                    match_number[match_index] |= 1 << bit_matched;
                }
            }
        }
        fclose(loop_file);
    }
}

//Function purpose: Frees malloc'd memory assigned when forming TABI struct in 
//                  struct tabi_record read_tabi_file() function.
// 
//Output:           void
// 
//Input:            struct tabi_record *tabi_record
// 
//Name:             free_tabi_record
// 
void free_tabi_record(struct tabi_record *tabi_record) {
    free(tabi_record->pathname);
    free(tabi_record->hashes);
}


/// @brief Create a TCBI file from a TBBI file.
/// @param out_pathname A path to where the new TCBI file should be created.
/// @param in_pathname A path to where the existing TBBI file is located.
void stage_3(char *out_pathname, char *in_pathname) {
    FILE *f_in = fopen(in_pathname, "r");
    if (f_in == NULL) {
        perror(in_pathname);
        exit(1);
    }
    FILE *f_out = fopen(out_pathname, "w");
    if (f_out == NULL) {
        perror(out_pathname);
        exit(1);
    }    

    uint8_t num_records = read_magic_txbi_header(f_in, TYPE_B_MAGIC, 
                                                in_pathname);

    write_magic_txbi_header(f_out, TYPE_C_MAGIC, out_pathname, num_records);

    for (int i = 0; i < num_records; i++) {
        establish_record(f_in, f_out, in_pathname, out_pathname);
    }

    if (fgetc(f_in) != EOF) {
        fprintf(stderr, "Invalid TABI file: leftover data.\n");
        exit(1);
    } 
    else if (ferror(f_in)) {
        perror(in_pathname);
        exit(1);
    }

    fclose(f_in);
    fclose(f_out);
}

//Function purpose: Read in a TBBI file and create a struct to easily recall
//                  data in later functions. 
// 
//Output:           struct tbbi_record
// 
//Input:            FILE *file_in, char *in_pathname
// 
//Name:             read_tbbi_file
// 
struct tbbi_record read_tbbi_file(FILE *file_in, char *in_pathname) {
    struct tbbi_record record;
    record.pathname_len = read_little_endian (file_in, in_pathname,
                                                PATHNAME_LEN_SIZE, 
                                                "filename len", TYPE_B_MAGIC);
    record.pathname = malloc(sizeof(char) * (record.pathname_len + 1));
    if (record.pathname == NULL) {
        perror("read_tbbi_file");
        exit(1);
    }

    int path_read = fread(record.pathname, 1, record.pathname_len, file_in);
    if (path_read < record.pathname_len) {
        if (feof(file_in)) {
            fprintf(stderr, 
            "Invalid TBBI file: encountered early end-of-file\
             when trying to read the field\
             `filename' (%d bytes)\n", record.pathname_len);
            exit(1);
        }
        else {
            perror(in_pathname);
            exit(1);
        }
    }
    record.pathname[record.pathname_len] = '\0';

    record.num_blocks = read_little_endian (file_in, in_pathname, 
                                            NUM_BLOCKS_SIZE, "num blocks", 
                                            TYPE_B_MAGIC);
    
    size_t num_matches = num_tbbi_match_bytes(record.num_blocks);
    record.matches = malloc(sizeof(uint8_t) * num_matches);
    if (record.matches == NULL) {
        perror("read_tbbi_file");
        exit(1);
    }
    for (uint32_t i = 0; i < num_matches; i++){
        record.matches[i] = read_little_endian(file_in, in_pathname, 
                                                1, "matches", 
                                                TYPE_B_MAGIC);
    }

    return record;
}

//Function purpose: To collate all of the functions involved in establishing 
//                  each record. 
//                  
// 
//Output:           void
// 
//Input:            FILE *file_in, char *in_pathname, 
//                  FILE *file_out, char *out_pathname
// 
//Name:             establish_record
// 
void establish_record (
    FILE *file_in, 
    FILE *file_out, 
    char *in_pathname, 
    char *out_pathname) {
    
    struct tbbi_record record = read_tbbi_file(file_in, in_pathname);
    check_invalid_paths(record.pathname);
    
    tcbi_pathname(file_out, &record);
    
    struct stat stats;
    if (stat(record.pathname, &stats) != 0) {
        perror(record.pathname);
        exit(1);
    }

    print_permissions(file_out, stats.st_mode, out_pathname);

    if (S_ISDIR(stats.st_mode)) {
        make_little_endian(file_out, 0, FILE_SIZE_SIZE);
        make_little_endian(file_out, 0, NUM_UPDATES_SIZE);
    }   
    else {
        size_t num_blocks_in_file = number_of_blocks_in_file(stats.st_size);

        if (num_blocks_in_file != record.num_blocks) {
            perror(in_pathname);
            exit(1);
        }

        make_little_endian(file_out, stats.st_size, FILE_SIZE_SIZE);
        int num_updates = count_updates(&record);
        make_little_endian(file_out, num_updates, NUM_UPDATES_SIZE);
        write_updates(&record, file_out, out_pathname);
    }
    free_tbbi_record(&record);
}

//Function purpose: Create pathname for TCBI file
// 
//Output:           void
// 
//Input:            FILE *file_out, struct tbbi_record *tbbi_record
// 
//Name:             tcbi_pathname
// 
void tcbi_pathname(FILE *file_out, struct tbbi_record *tbbi_record) {
    make_little_endian(file_out, tbbi_record->pathname_len, PATHNAME_LEN_SIZE);
    size_t path_write = fwrite(tbbi_record->pathname, sizeof(char), 
                                tbbi_record->pathname_len, file_out);
    if (path_write < tbbi_record->pathname_len) {
        fprintf(stderr, "Invalid TBBI file: incorrect number of blocks.\n");
        exit(1);
    }
}

//Function purpose: Locate permissions of a file for User, Group and Other and 
//                  print relevant values in a string, and write into TCBI file.
// 
//Output:           void
// 
//Input:            FILE *file_out, mode_t mode, char *out_pathname
// 
//Name:             print_permissions
// 
void print_permissions(FILE *file_out, mode_t mode, char *out_pathname) {
    char permission_string[MODE_SIZE];
    mode_t masks[9] = {S_IRUSR, S_IWUSR, S_IXUSR, S_IRGRP, S_IWGRP, 
                    S_IXGRP, S_IROTH, S_IWOTH, S_IXOTH};
    char *permission_format = "rwxrwxrwx";

    if (S_ISDIR(mode)) {
        permission_string[0] = 'd';
    }
    else if (S_ISREG(mode)) {
        permission_string[0] = '-';
    }
    else {
        perror("print_permissions");
        exit(1);
    }
    for (int i = 0; i < 9; i++) {
        if (mode & masks[i]) {
            permission_string[i+1] = permission_format[i];
        }
        else {
            permission_string[i+1] = '-';
        }
    }
    size_t permission_write = fwrite(permission_string, 1, MODE_SIZE, file_out);
    if (permission_write < MODE_SIZE) {
        perror(out_pathname);
        exit(1);
    }
}


//Function purpose: Count the matching bits to determine number of updates.
// 
//Output:           int
// 
//Input:            struct tbbi_record *tbbi_record
// 
//Name:             count_updates
// 
int count_updates (struct tbbi_record *tbbi_record) {
    int num_updates = 0;
    int block_number = 0;
    int num_matches = num_tbbi_match_bytes(tbbi_record->num_blocks);
    for (int byte_posn = 0; byte_posn < num_matches; byte_posn++) {
        for (int bit_position = 7; bit_position >= 0; bit_position--) {
            int bit = tbbi_record->matches[byte_posn] & (1 << bit_position);
            if (block_number >= tbbi_record->num_blocks) {
                if (bit != 0) {
                    fprintf(stderr, "Invalid TBBI:  \
                    number of bytes\n");
                    exit(1);
                }
            }
            else if (bit == 0) {
                num_updates++;
            }
            block_number++;
        }
    }
    return num_updates;
}

//Function purpose: Reads through all hashes and updates any hashes that do not
//                  match to show 0, while counting amount of updates.
// 
//Output:           void
// 
//Input:            struct tbbi_record * tbbi_record, 
//                  FILE *file_out, char *out_pathname
//
//Name:             write_updates            
// 
void write_updates(
    struct tbbi_record *tbbi_record,
    FILE *file_out, 
    char *out_pathname) {

        int update_number = 0;
        FILE *record_file = fopen(tbbi_record->pathname, "r");
        for (int block = 0; block < tbbi_record->num_blocks; block++) {
            uint32_t match_index = block / 8;
            int bit_matched = (7 - block % 8);
            int bit = tbbi_record->matches[match_index] & (1 << bit_matched);

            if (bit == 0) {
                int position = fseek(record_file, block * BLOCK_SIZE, SEEK_SET);
                if (position == -1) {
                    perror(tbbi_record->pathname);
                    exit(1);
                }
                char byte_buffer[BLOCK_SIZE];
                size_t byte_read = fread(byte_buffer, 1, 
                                        BLOCK_SIZE, record_file);
                
                make_little_endian(file_out, block, BLOCK_INDEX_SIZE);
                make_little_endian(file_out, byte_read, UPDATE_LEN_SIZE);
                
                size_t byte_written = fwrite(byte_buffer, 1, 
                                            byte_read, file_out);
                if (byte_written < byte_read) {
                    perror(out_pathname);
                    exit(1);
                }
            }
            update_number++;
        }
        fclose(record_file);
}

//Function purpose: Frees malloc'd memory assigned when forming TBBI struct in 
//                  struct tbbi_record read_tbbi_file() function.
// 
//Output:           void
// 
//Input:            struct tbbi_record *tbbi_record
// 
//Name:             free_tbbi_record
// 
void free_tbbi_record(struct tbbi_record *tbbi_record) {
    free(tbbi_record->pathname);
    free(tbbi_record->matches);
}



/// @brief Apply a TCBI file to the filesystem.
/// @param in_pathname A path to where the existing TCBI file is located.
void stage_4(char *in_pathname) {
    FILE *f_in = fopen(in_pathname, "r");
    if (f_in == NULL) {
        
        perror(in_pathname);
        exit(1);
    }
    
    uint8_t num_records = read_magic_txbi_header(f_in, 
                                                TYPE_C_MAGIC, 
                                                in_pathname);

    for (int i = 0; i < num_records; i++) {
        establish_records_s4(f_in, in_pathname);
    }

    if (fgetc(f_in) != EOF) {
        fprintf(stderr, "Invalid TABI file: leftover data.\n");
        exit(1);
    } 
    else if (ferror(f_in)) {
        perror(in_pathname);
        exit(1);
    }
    fclose(f_in);
} 

//Function purpose: Similar to establish_records() in Stage 3, this function 
//                  establishes records of a file, with addition to checks for
//                  changing permissions and writing instead of num updates
//                  
// 
//Output:           void
// 
//Input:            FILE *file_in, FILE *file_out,
//                  char *in_pathname, char *out_pathname
// 
//Name:             establish_records_s4
//
void establish_records_s4 (FILE *file_in, char *in_pathname) {
    struct tcbi_record record = read_tcbi_file(file_in, in_pathname);
    
    if (record.mode[0] == 'd') {
        directory_record(&record);
    }
    
    else {
        open_and_update_tcbi(&record, file_in, in_pathname);
    }

    check_invalid_paths(record.pathname);

    free_tcbi_record(&record);       
}

//Function purpose: Opens and runs checks if directory exists and makes one with
//                  if non-existent
// 
//Output:           void
// 
//Input:            struct tcbi_record *tcbi_record
// 
//Name:             directory_record
//
void directory_record(struct tcbi_record *tcbi_record) {
    DIR *dir = opendir(tcbi_record->pathname);
    if (dir == NULL) {
        if (errno == ENOENT) {
            if (mkdir(tcbi_record->pathname, tcbi_record->permission) != 0) {
                perror(tcbi_record->pathname);
                exit(1);
            }
        }
        else {
            perror(tcbi_record->pathname);
            exit(1);
        }
    }
    else {
        if (chmod(tcbi_record->pathname, tcbi_record->permission) != 0) {
            perror(tcbi_record->pathname);
            exit(1);
        }
        closedir(dir);
    }
}

//Function purpose: Read in a TCBI file and create a struct to easily recall
//                  data in later functions. 
//Output:           struct tcbi_record
// 
//Input:            FILE *file_in, char *in_pathname
// 
//Name:             read_tcbi_file
// 
struct tcbi_record read_tcbi_file (FILE *file_in, char *in_pathname) {
    struct tcbi_record record;

    record.pathname_len = read_little_endian(file_in, in_pathname, 
                                            PATHNAME_LEN_SIZE, "filename len", 
                                            TYPE_C_MAGIC);
    record.pathname = malloc(sizeof(char) * (record.pathname_len + 1));
    if (record.pathname == NULL)  {
        perror("read_tcbi_file");
        exit(1);
    }

    int path_read = fread(record.pathname, 1, record.pathname_len, file_in);
    if (path_read < record.pathname_len) {
        if (feof(file_in)) {
            fprintf(stderr, 
            "Invalid TCBI file: encountered early end-of-file"
            "when trying to read the field"
            "`filename' (%d bytes)\n", record.pathname_len);
            exit(1);
        }
        else {
            perror(in_pathname);
            exit(1);
        }
    }
    record.pathname[record.pathname_len] = '\0';

    check_permissions(&record, file_in, in_pathname);

    record.size = read_little_endian(file_in, in_pathname, FILE_SIZE_SIZE,
                                    "file size", TYPE_C_MAGIC);

    record.num_updates = read_little_endian(file_in, 
                                            in_pathname, 
                                            NUM_UPDATES_SIZE, 
                                            "num updates", 
                                            TYPE_C_MAGIC);

    return record;
}

//Function purpose: Read in a TCBI file's permission, revert to big endian and
//                  modify the permissions for updating TCBI file
//Output:           void
// 
//Input:            struct tcbi_record *tcbi_record, FILE *file_in,
//                  char *in_pathname
// 
//Name:             check_permissions
// 
void check_permissions (
    struct tcbi_record *tcbi_record, 
    FILE *file_in,
    char *in_pathname) {
    tcbi_record->mode = malloc(MODE_SIZE * sizeof(char));
    if (tcbi_record->mode == NULL) {
        perror("read_tcbi_file: malloc mode");
        exit(1);
    }

    int permission_read = fread(tcbi_record->mode, 1, MODE_SIZE, file_in);
    if (permission_read < MODE_SIZE) {
        if (feof(file_in)) {
            fprintf(stderr, 
            "Invalid TCBI file: encountered early end-of-file\
             when trying to read the field\
             `mode' (%d bytes) \n", MODE_SIZE);
            exit(1);
        }
    }

    if (tcbi_record->mode[0] != 'd' && tcbi_record->mode[0] != '-') {
        perror(in_pathname);
        exit(1);
    }
    else {
        if (tcbi_record->mode[0] == 'd') {
            tcbi_record->permission = S_IFDIR;
        }
        else {
            tcbi_record->permission = S_IFREG;
        }
    }

    char *permission_format = "rwxrwxrwx";
    for (int i = 0; i < (MODE_SIZE - 1); i++) {
        if (tcbi_record->mode[i+1] == permission_format[i]) {
            tcbi_record->permission |= 1u << (MODE_SIZE - (2 + i));
        }
        else if (tcbi_record->mode[i+1] == '-') {
            tcbi_record->permission &= ~(1u << (MODE_SIZE - (2 + i)));
        }
        else {
            fprintf(stderr, "Invalid byte read in permission field\n");
            exit(1);
        }    
    }
}

//Function purpose: Opens a TCBI file, updating its permissions, 
//                  truncating its size and updating contents 
// 
//Output:           void
// 
//Input:            struct tcbi_record *tcbi_record, FILE *file_in,
//                  char *in_pathname
// 
//Name:             open_and_update_tcbi
// 
void open_and_update_tcbi (
    struct tcbi_record *tcbi_record, 
    FILE *file_in, 
    char *in_pathname) {

    
    int file_descriptor = open(tcbi_record->pathname, 
                                O_WRONLY | O_CREAT, tcbi_record->permission);
        if (file_descriptor == -1) {
            perror(tcbi_record->pathname);
            if (errno == EISDIR) {
                close(file_descriptor);
                exit(1);
            }
            exit(1);
        }

        off_t original_size = lseek(file_descriptor, 0, SEEK_END);
        if (original_size == -1) {
            perror(tcbi_record->pathname);
            exit(1);
        }

        int permission_mod = fchmod(file_descriptor, tcbi_record->permission);
        if (permission_mod != 0) {
            perror(tcbi_record->pathname);
            exit(1);
        } 


        int truncated = ftruncate(file_descriptor, tcbi_record->size);
        if (truncated == -1) {
            perror(tcbi_record->pathname);
            exit(1);
        }

        size_t num_sender_blocks = number_of_blocks_in_file(tcbi_record->size);

        update_bytes_loop(
                            tcbi_record, 
                            file_in, 
                            in_pathname, 
                            num_sender_blocks, 
                            file_descriptor
                        );
        
        close(file_descriptor);
}

//Function purpose: Read, validate and update blocks from input file.
//                  Loop is tallying through number of updates in TCBI file. 
// 
//Output:           void
// 
//Input:            struct tcbi_record *tcbi_record, FILE *file_in, 
//                  char *in_pathname, size_t num_sender_blocks,
//                  int file_descriptor
// 
//Name:             update_bytes_loop
// 
void update_bytes_loop (
    struct tcbi_record *tcbi_record, 
    FILE *file_in, 
    char *in_pathname,
    size_t num_sender_blocks,
    int file_descriptor) {

    int *seen = calloc(num_sender_blocks, sizeof(int));

    for (int j = 0; j < tcbi_record->num_updates; j++) {
        
        int block_index = block_index_check(file_in, in_pathname, 
                                            num_sender_blocks, seen);

        uint16_t update_length = read_little_endian(file_in, in_pathname, 
                                                    UPDATE_LEN_SIZE, 
                                                    "update length", 
                                                    TYPE_C_MAGIC);

        if (update_length > BLOCK_SIZE) {
            fprintf(stderr, "Update length is too large"
                    " for specific file\n");
            exit(1);
        }
        if (block_index == (num_sender_blocks - 1) && 
            tcbi_record->size % BLOCK_SIZE != 0) {
            if (update_length != tcbi_record->size % BLOCK_SIZE) {
                fprintf(stderr, "ERROR: Last update has"
                " incorrect size.\n");
                exit(1);
            }
        }
        else {
            if (update_length != BLOCK_SIZE) {
                fprintf(stderr, "ERROR: Update length must be equal to "
                "Block Size (%d bytes)\n", BLOCK_SIZE);
                exit(1);
            }
        }
        move_and_update_bytes(file_descriptor, block_index, 
                                update_length, file_in, in_pathname);
    } 
    free(seen);
}

//Function purpose: Read in little endian the index number of a block
//                  and align with seen array following error checks
// 
//Output:           int
// 
//Input:            FILE *file_in, char *in_pathname, size_t num_sender_blocks, 
//                  int *seen
// 
//Name:             block_index_check
// 
int block_index_check (
    FILE *file_in,
    char *in_pathname,
    size_t num_sender_blocks,
    int *seen
    ) {

        int block_index = read_little_endian(file_in, in_pathname, 
                                            BLOCK_INDEX_SIZE, "block index",
                                            TYPE_C_MAGIC);

        if (block_index >= num_sender_blocks) {
            fprintf(stderr, "ERROR: Block index exceeds file size.\n");
            exit(1);
        }

        if (seen[block_index] != 0) {
            fprintf(stderr, "ERROR: Duplicate update request"
            "found for block. \n");
            exit(1);
        }
        seen[block_index] = 1;
        return block_index;
}

//Function purpose: Read the TCBI file and seek the file and write updates
// 
//Output:           void
// 
//Input:            int file_descriptor, int block_index, uint16_t update_length
//                  FILE *file_in, char *in_pathname
// 
//Name:             move_and_update_bytes
// 
void move_and_update_bytes (
    int file_descriptor, 
    int block_index,
    uint16_t update_length,
    FILE *file_in,
    char *in_pathname
    ) {
    char byte_buffer[BLOCK_SIZE];
        int update_bytes = fread(byte_buffer, 1, update_length, file_in);
        if (update_bytes < update_length) {
            perror(in_pathname);
            exit(1);
        }

        off_t move_to_update = lseek(file_descriptor, 
                                    block_index * BLOCK_SIZE, SEEK_SET);

        if (move_to_update == -1) {
            perror(in_pathname);
            exit(1);
        }

        ssize_t update_written = write(file_descriptor, 
                                        byte_buffer, update_length);

        if (update_written == -1) {
            perror(in_pathname);
            exit(1);
        }
        if (update_written != update_length) {
            fprintf(stderr, "ERROR: Partial write while updating file.\n");
            exit(1);
        }
}


//Function purpose: Frees malloc'd memory assigned when forming TCBI struct in 
//                  struct tcbi_record read_tcbi_file() function.
// 
//Output:           void
// 
//Input:            struct tcbi_record *tcbi_record
// 
//Name:             free_tcbi_record
//
void free_tcbi_record(struct tcbi_record *tcbi_record) {
    free(tcbi_record->pathname);
    free(tcbi_record->mode);
}


///////////////////////////SUBSET 5 HELPER FUNCTIONS////////////////////////////

//Function purpose: Set up a recursive function that determines if a file
//                  is a directory, and thus continues to traverse directories
//                  until a file is reached. Processes each file and directory
//                  and writes to output file.
// 
//Output:           int
// 
//Input:            FILE *file_out, char *directory_name
// 
//Name:             directory_to_tabi
//
int directory_to_tabi (FILE *file_out, char *directory_name) {
    DIR *directory = opendir(directory_name);
    if (directory == NULL) {
        fprintf(stderr, "Directory does not exist.\n");
        // perror(directory_name);
        exit(1);
    }


    struct dirent *dir_struct;

    uint64_t create_count = 0;

    while ((dir_struct = readdir(directory)) != NULL) {

        if (strcmp(dir_struct->d_name, ".") == 0 || 
            strcmp(dir_struct->d_name, "..") == 0) {
            continue;
        }

        char path[MAX_PATH_LENGTH];
        if (directory_name[0] == '.' && directory_name[1] == '\0') {
            snprintf(path, sizeof(path), "%s", dir_struct->d_name);
        } 
        else {
            snprintf(path, sizeof(path), 
            "%s/%s", directory_name, dir_struct->d_name);
            check_invalid_paths(path);
        }
        

        if (dir_struct->d_type == DT_DIR) {
            write_directory_to_tabi(file_out, path);
            create_count++;
            create_count += directory_to_tabi(file_out, path);
        }   
        else {
            write_file_to_tabi(file_out, directory_name, path);
            create_count++;
        }
    }
    closedir(directory);
    return create_count;
}


//Function purpose: Takes the pathname of a directory and makes it little_endian
//                  to write to output file
// 
//Output:           void
// 
//Input:            FILE *file_out, char *pathname
// 
//Name:             write_directory_to_tabi
//
void write_directory_to_tabi (FILE *file_out, char *pathname) {
    uint16_t path_name_length = strlen(pathname);
    make_little_endian(file_out, path_name_length, PATHNAME_LEN_SIZE);

    size_t path = fwrite(pathname, sizeof(char), path_name_length, file_out);
    if (path < path_name_length) {
        perror(pathname);
        exit(1);
    }
    uint32_t num_blocks = 0;
    make_little_endian(file_out, num_blocks, NUM_BLOCKS_SIZE);
}

//Function purpose: A series of checks to see if the pathname provided is valid
//                  and matches the current working directory.
// 
//Output:           int
// 
//Input:            char *in_pathname
// 
//Name:             check_invalid_paths
//
int check_invalid_paths (char *in_pathname) {
    char current_dir[MAX_PATH_LENGTH];
    char absolute_path[MAX_PATH_LENGTH];
    if (getcwd(current_dir, sizeof(current_dir)) == NULL) {
        perror("getcwd");
        exit(1);
    }

    if (realpath(in_pathname, absolute_path) == NULL) {
        perror(in_pathname);
        exit(1);
    }
   
    size_t cwd_length = strlen(current_dir);
    if (cwd_length == 0) {
        fprintf(stderr, "ERROR: Invalid directory name\n");
        exit(1);
    }

    int string_byte_compare = strncmp(absolute_path, current_dir, cwd_length);
    if (string_byte_compare != 0) {
        fprintf(stderr, "ERROR: Absolute path does not match Relative path.\t");
        fprintf(stderr, "Abspath: %s\t", absolute_path);
        fprintf(stderr, "Cwdpath: %s\n", current_dir);
        exit(1);
    }

    return 0;
}
